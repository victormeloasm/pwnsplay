#!/usr/bin/env python3
"""
Reproduz um crash do VLC com um arquivo de teste local, coleta logs,
exporta o core via systemd-coredump e gera um backtrace com GDB.

Uso:
    python3 repro_vlc_core.py vp9_reschange_64x64_to_64x8192_tc0.ivf

Dependências opcionais:
    sudo apt install gdb systemd-coredump
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import platform
import resource
import shlex
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Sequence


EXPECTED_SHA256 = (
    "f26bdefbdfd0b44359e314e0bfde7aea"
    "979d29f80f598749dcca68ab34f54649"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_capture(
    argv: Sequence[str],
    *,
    timeout: int = 120,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        list(argv),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
        env=env,
    )


def enable_core_dumps_safely() -> tuple[int, int]:
    """
    Habilita core dumps no processo Python antes do fork.

    Não usamos preexec_fn: além de frágil, qualquer exceção no filho vira
    apenas "Exception occurred in preexec_fn". O VLC herda este limite.
    """
    soft, hard = resource.getrlimit(resource.RLIMIT_CORE)

    # Só podemos elevar o limite soft até o limite hard atual.
    target = hard
    try:
        resource.setrlimit(resource.RLIMIT_CORE, (target, hard))
    except (OSError, ValueError):
        # O fallback pelo GDB ainda consegue gerar um core.
        pass

    return resource.getrlimit(resource.RLIMIT_CORE)


def wait_for_coredump(pid: int, seconds: int = 15) -> bool:
    if shutil.which("coredumpctl") is None:
        return False

    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        result = run_capture(
            ["coredumpctl", "--no-pager", "info", f"_PID={pid}"],
            timeout=15,
        )
        if result.returncode == 0 and "No coredumps found" not in result.stdout:
            return True
        time.sleep(1)

    return False


def export_systemd_core(pid: int, output: Path) -> tuple[bool, str]:
    attempts = [
        ["coredumpctl", "--no-pager", "dump", f"_PID={pid}", f"--output={output}"],
        ["coredumpctl", "--no-pager", "dump", str(pid), f"--output={output}"],
    ]

    logs: list[str] = []
    for command in attempts:
        result = run_capture(command, timeout=120)
        logs.append(
            f"$ {shlex.join(command)}\n"
            f"exit={result.returncode}\n{result.stdout}\n"
        )
        if result.returncode == 0 and output.exists() and output.stat().st_size:
            return True, "\n".join(logs)

    return False, "\n".join(logs)


def write_gdb_backtrace(executable: Path, core: Path, output: Path) -> bool:
    gdb = shutil.which("gdb")
    if gdb is None:
        output.write_text("GDB não encontrado.\n", encoding="utf-8")
        return False

    command = [
        gdb,
        "-q",
        "-batch",
        "-ex", "set pagination off",
        "-ex", "set confirm off",
        "-ex", "set print thread-events off",
        "-ex", "info files",
        "-ex", "info sharedlibrary",
        "-ex", "info registers",
        "-ex", "x/16i $pc-32",
        "-ex", "thread apply all bt full",
        str(executable),
        str(core),
    ]
    result = run_capture(command, timeout=180)
    output.write_text(
        f"$ {shlex.join(command)}\n"
        f"exit={result.returncode}\n\n"
        f"{result.stdout}",
        encoding="utf-8",
    )
    return result.returncode == 0


def fallback_gdb_run(
    executable: Path,
    vlc_args: list[str],
    core: Path,
    backtrace: Path,
    env: dict[str, str],
) -> bool:
    gdb = shutil.which("gdb")
    if gdb is None:
        return False

    command = [
        gdb,
        "-q",
        "-batch",
        "-ex", "set pagination off",
        "-ex", "set confirm off",
        "-ex", "set print thread-events off",
        "-ex", "handle SIGSEGV stop print nopass",
        "-ex", "run",
        "-ex", f"generate-core-file {core}",
        "-ex", "info registers",
        "-ex", "x/16i $pc-32",
        "-ex", "thread apply all bt full",
        "--args",
        str(executable),
        *vlc_args,
    ]

    result = run_capture(command, timeout=180, env=env)
    backtrace.write_text(
        f"$ {shlex.join(command)}\n"
        f"exit={result.returncode}\n\n"
        f"{result.stdout}",
        encoding="utf-8",
    )
    return core.exists() and core.stat().st_size > 0


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Reproduz crash do VLC, coleta core e gera backtrace."
    )
    parser.add_argument("sample", type=Path, help="Arquivo IVF de teste")
    parser.add_argument(
        "--player",
        default="cvlc",
        help="Executável do VLC (padrão: cvlc)",
    )
    parser.add_argument(
        "--skip-hash-check",
        action="store_true",
        help="Não exigir o SHA-256 conhecido do PoC",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        help="Diretório de saída",
    )
    args = parser.parse_args()

    sample = args.sample.expanduser().resolve()
    if not sample.is_file():
        raise SystemExit(f"Arquivo não encontrado: {sample}")

    player = shutil.which(args.player)
    if player is None:
        raise SystemExit(f"Executável não encontrado: {args.player}")

    executable = Path(player).resolve()
    sample_hash = sha256_file(sample)

    if not args.skip_hash_check and sample_hash != EXPECTED_SHA256:
        raise SystemExit(
            "SHA-256 inesperado.\n"
            f"Esperado: {EXPECTED_SHA256}\n"
            f"Obtido:  {sample_hash}\n"
            "Use --skip-hash-check apenas se estiver analisando outro arquivo."
        )

    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir
        else Path.cwd() / f"vlc_crash_{timestamp}"
    )
    output_dir.mkdir(parents=True, exist_ok=False)

    vlc_log = output_dir / "vlc.log"
    metadata_file = output_dir / "metadata.json"
    coredump_info_file = output_dir / "coredumpctl-info.txt"
    coredump_export_log = output_dir / "coredumpctl-export.txt"
    core_file = output_dir / "core.vlc"
    backtrace_file = output_dir / "gdb-backtrace.txt"

    vlc_args = [
        "-vvv",
        "--no-one-instance",
        "--avcodec-hw=none",
        "--no-audio",
        "--vout=dummy",
        "--play-and-exit",
        str(sample),
    ]
    command = [str(executable), *vlc_args]

    env = os.environ.copy()
    env["LC_ALL"] = "C"
    env["LANG"] = "C"

    version = run_capture([str(executable), "--version"], timeout=20)
    core_pattern = ""
    try:
        core_pattern = Path("/proc/sys/kernel/core_pattern").read_text(
            encoding="utf-8"
        ).strip()
    except OSError:
        pass

    core_soft, core_hard = enable_core_dumps_safely()

    print(f"[+] Sample: {sample}")
    print(f"[+] SHA-256: {sample_hash}")
    print(f"[+] Saída: {output_dir}")
    print(f"[+] RLIMIT_CORE: soft={core_soft}, hard={core_hard}")
    print(f"[+] Executando: {shlex.join(command)}")

    with vlc_log.open("w", encoding="utf-8") as log_handle:
        process = subprocess.Popen(
            command,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            text=True,
            env=env,
            start_new_session=True,
        )
        pid = process.pid
        returncode = process.wait(timeout=120)

    signal_number: int | None = None
    if returncode < 0:
        signal_number = -returncode

    metadata = {
        "timestamp": timestamp,
        "sample": str(sample),
        "sample_sha256": sample_hash,
        "player": str(executable),
        "command": command,
        "pid": pid,
        "returncode": returncode,
        "signal": signal_number,
        "signal_name": (
            signal.Signals(signal_number).name
            if signal_number is not None
            else None
        ),
        "platform": platform.platform(),
        "kernel": platform.release(),
        "python": sys.version,
        "core_pattern": core_pattern,
        "rlimit_core_soft": core_soft,
        "rlimit_core_hard": core_hard,
        "vlc_version": version.stdout,
    }
    metadata_file.write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    if signal_number == signal.SIGSEGV:
        print(f"[+] VLC caiu com SIGSEGV, PID {pid}")
    else:
        print(f"[!] Retorno do VLC: {returncode}")

    core_exported = False

    if shutil.which("coredumpctl") is not None and wait_for_coredump(pid):
        info = run_capture(
            ["coredumpctl", "--no-pager", "info", f"_PID={pid}"],
            timeout=30,
        )
        coredump_info_file.write_text(info.stdout, encoding="utf-8")

        core_exported, export_log = export_systemd_core(pid, core_file)
        coredump_export_log.write_text(export_log, encoding="utf-8")

    if core_exported:
        print(f"[+] Core exportado: {core_file}")
        write_gdb_backtrace(executable, core_file, backtrace_file)
        print(f"[+] Backtrace: {backtrace_file}")
    else:
        print("[!] systemd-coredump não exportou o core.")
        print("[*] Tentando nova reprodução dentro do GDB...")
        fallback_core = output_dir / "core.vlc.gdb"
        fallback_bt = output_dir / "gdb-fallback.txt"

        if fallback_gdb_run(
            executable,
            vlc_args,
            fallback_core,
            fallback_bt,
            env,
        ):
            print(f"[+] Core gerado pelo GDB: {fallback_core}")
            print(f"[+] Backtrace: {fallback_bt}")
        else:
            print("[!] Não foi possível gerar o core automaticamente.")
            print(f"[*] Consulte os logs em: {output_dir}")

    print("\nArquivos produzidos:")
    for path in sorted(output_dir.iterdir()):
        print(f"  {path.name:28s} {path.stat().st_size:>12d} bytes")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
